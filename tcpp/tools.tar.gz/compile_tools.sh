#!/bin/bash


g++ -o stats evaluate.cc -O3
g++ -o crossValidation val.cc -O3
