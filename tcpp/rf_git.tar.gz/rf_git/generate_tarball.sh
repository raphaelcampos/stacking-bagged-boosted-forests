#!/bin/bash

tar cvzf rf_git.tar.gz ../rf_git/*.{cc,hpp,h,sh} ../rf_git/ttmath
